const fs = require('fs');
const java = require('java');
const baseDir = './javalib';
const dependencies = fs.readdirSync(baseDir);
dependencies.forEach(function(dependency){
  java.classpath.push(baseDir + '/' + dependency);
});
exports.java = java;
