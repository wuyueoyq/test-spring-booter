const java = require('./javainit').java;
const JdbcDatabaseTester = java.import('org.dbunit.JdbcDatabaseTester');
const FlatXmlDataSetBuilder = java.import('org.dbunit.dataset.xml.FlatXmlDataSetBuilder');
const RunScript = java.import('org.h2.tools.RunScript');
const FileInputStream = java.import('java.io.FileInputStream');
const Charset = java.import('java.nio.charset.Charset');
const DatabaseOperation = java.import('org.dbunit.operation.DatabaseOperation');
const Assertion =  java.import('org.dbunit.Assertion');

const JDBC_URL = 'jdbc:h2:tcp://localhost/~/test;Mode=Oracle';
const USER = 'sa';
const PASSWORD = '';
RunScript.executeSync(JDBC_URL, USER, PASSWORD, "schema.sql", Charset.defaultCharsetSync(), false);

const dbtester = new JdbcDatabaseTester('org.h2.Driver', JDBC_URL, USER, PASSWORD);
const dataset = (new FlatXmlDataSetBuilder()).buildSync(new FileInputStream('./dataset.xml'));
const connection = dbtester.getConnectionSync();
DatabaseOperation.CLEAN_INSERT.executeSync(connection, dataset);

connection.getConnectionSync().commitSync();


const datasetResult = dbtester.getConnectionSync().createDataSetSync();

console.log(datasetResult.getTableSync('genders').getRowCountSync());

const datasetExpected = (new FlatXmlDataSetBuilder()).buildSync(new FileInputStream('./dataset-expected.xml'));
Assertion.assertEqualsSync(datasetExpected.getTableSync('genders'), datasetResult.getTableSync('genders'));
Assertion.assertEqualsSync(datasetExpected.getTableSync('persons'), datasetResult.getTableSync('persons'));

connection.close();