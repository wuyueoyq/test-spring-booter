const java = require('./javainit').java;
const JdbcDatabaseTester = java.import('org.dbunit.JdbcDatabaseTester');
const dbtester = new JdbcDatabaseTester('org.h2.Driver', 'jdbc:h2:./h2test;MODE=Oracle', 'sa', '');